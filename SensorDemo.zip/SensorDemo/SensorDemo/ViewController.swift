//
//  ViewController.swift
//  SensorDemo
//
//  Created by admin on 02/04/2019.
//  Copyright © 2019 admin. All rights reserved.
//

import UIKit
import CoreMotion
import AudioToolbox

class ViewController: UIViewController
{
    @IBOutlet var view1: UIView!
    @IBOutlet weak var okLabel: UILabel!
    @IBOutlet weak var slider: UISlider!
    
    var motionManager = CMMotionManager()
    var queueBuffer = OperationQueue()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        okLabel.isHidden = true
        
        motionManager.startDeviceMotionUpdates(to: queueBuffer)
        {
            (motion,error) in
            if motion?.attitude.roll ?? 0 == 1.0
            {
               self.view1.backgroundColor = UIColor.blue
            }else
            {
                self.view1.backgroundColor = UIColor.green
            }
        }
        
    }

    @IBAction func goToPayment(_ sender: Any)
    {
        //self.okLabel.isHidden = false
        motionManager.startDeviceMotionUpdates(to: queueBuffer)
        {
            (motion,error) in
            print(motion?.attitude.roll)
            
            DispatchQueue.main.async
            {
                self.slider.value = Float((motion?.attitude.roll ?? 0)*1.4)
                if self.slider.value == 1.0
                {
                    self.okLabel.isHidden = false
                    self.motionManager.stopDeviceMotionUpdates()
                    AudioServicesPlayAlertSound(SystemSoundID(kSystemSoundID_Vibrate))
                    
                }
            }
            
        }
    }
    
}

