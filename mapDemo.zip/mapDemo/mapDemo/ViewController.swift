//
//  ViewController.swift
//  mapDemo
//
//  Created by admin on 26/02/2019.
//  Copyright © 2019 admin. All rights reserved.
//

import UIKit
import MapKit //for the map reference
import CoreLocation

class Global
{
    var anoteList = [MKPointAnnotation]()
    var locationList = [CLLocationCoordinate2D]()
    var titleList = [String]()
    var subtitleList = [String]()
    
    var arrayLength = [Int]()
    
    let defualtsLoc = UserDefaults.standard
    let defualtsTit = UserDefaults.standard
    let defualtsSub = UserDefaults.standard
    
    //let map = [String:[Double]]()
    
    func saveanotes()
    {
        //defualts.set(map, forKey:"mapkey")
    
        defualtsLoc.set(locationList, forKey:"locallist")
        defualtsTit.set(titleList, forKey: "titlellist")
        defualtsSub.set(subtitleList, forKey: "subtitlelist")
    }
    
    func loadanoList()
    {
        if let locFromStorage = defualtsLoc.array(forKey: "locallist") as? [CLLocationCoordinate2D]
        {
            locationList = locFromStorage
        }
        if let titleFromStorage = defualtsTit.array(forKey: "titellist") as? [String]
        {
            titleList = titleFromStorage
        }
        if let subTFromStorage = defualtsSub.array(forKey: "subtitlelist") as? [String]
        {
            subtitleList = subTFromStorage
        }
        
        
        for index in arrayLength
        {
            let annotation = MKPointAnnotation()
            
            annotation.coordinate = locationList[index]
            annotation.title = titleList[index]
            annotation.subtitle = subtitleList[index]
            
            anoteList.append(annotation)
        }
    }
}

let global = Global()

//CLLocationManagerDelegate er en protocol (næsten tilsvarende til interface i Java)
class ViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate
{
    var locationManager = CLLocationManager()
    
    @IBOutlet weak var textfield: UITextField!
    @IBOutlet weak var textView: UITextView!
    @IBOutlet weak var mapView: MKMapView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        //global.loadanoList()
        
       for anote in global.anoteList
        {
            mapView.addAnnotation(anote)
        }
        
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization() // ask permission from user
        locationManager.startUpdatingLocation() //close whenever you like to
        
        //locationManager.desiredAccuracy =  // sets accuracy
        
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView?
    {
        var annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: "Annotationview")
        
        if annotationView == nil
        {
            annotationView = MKAnnotationView(annotation: annotation, reuseIdentifier: "AnnotationView")
        }
        
        if annotation.title == "title"
        {
            annotationView?.image = UIImage(named: "cake icon")
        }
        
        
        annotationView?.canShowCallout = true
        
        return annotationView
    }
    
    
    @IBAction func changeText(_ sender: Any)
    {
        for anote in global.anoteList
        {
            if anote.title == textfield.text
            {
                anote.subtitle = textView.text
            }
        }
    }
    
    @IBAction func saveAnnotations(_ sender: Any)
    {
        global.saveanotes()
    }
    
    //
    @IBAction func longPressPressed(_ sender: UILongPressGestureRecognizer)
    {
        let annotation = MKPointAnnotation()
        
        if sender.state == .ended
        {
            //print("long pressed")
            //add new pin
            let gpsCoord = mapView.convert(sender.location(in: mapView), toCoordinateFrom: mapView)
            
            annotation.coordinate = gpsCoord
            annotation.title = textfield.text   //always vissible
            annotation.subtitle = textView.text //appear on click
            
            global.locationList.append(gpsCoord)
            //global.titleList.append(textfield.text)
            global.subtitleList.append(textView.text)
            global.arrayLength.append(global.locationList.count-1)
            
            global.anoteList.append(annotation)
            mapView.addAnnotation(annotation)
        }
        
    }
    
    //Delegate pattern remember for exam!!!
    
    //updates new location
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation])
    {
        //print("new location \(locations.first)")
        
        if let coord = locations.first?.coordinate
        {
            //print("current coordinate \(coord)")
            let region = MKCoordinateRegion(center: coord, latitudinalMeters: 400, longitudinalMeters: 400)
            mapView.setRegion(region, animated: true)
        }
        
    }
    
    //Authorication
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus)
    {
        switch status
        {
        case .authorizedWhenInUse:
            mapView.showsUserLocation = true
        default:
            mapView.showsUserLocation = false
            locationManager.startUpdatingLocation()
        }
    }
    
}

/*
extension ViewController: MKMapViewDelegate
{
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView?
    {
        var annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: "Annotationview")
        
        if annotationView == nil
        {
            annotationView = MKAnnotationView(annotation: annotation, reuseIdentifier: "AnnotationView")
        }
        
        if annotation.title == "my pin"
        {
            annotationView?.image = UIImage(named: "cake icon")
        }
        
        
        annotationView?.canShowCallout = true
        
        return annotationView
    }
    
    //option
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView)
    {
        //print("annotation seleted \(view.annotation?.title)")
    }
}
*/
