//
//  DrawViewController.swift
//  fotodemo
//
//  Created by admin on 08/03/2019.
//  Copyright © 2019 admin. All rights reserved.
//

import UIKit

class DrawViewController: UIViewController
{
    @IBOutlet weak var imageViewDraw: UIImageView!
    
    //default point
    var lastPosition: CGPoint = CGPoint(x: 0, y: 0)
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        //print("began \(touches.first)")
        let touch = touches.first
        if let position = touch?.location(in: imageViewDraw)
        {
            //print(position)
            lastPosition = position
            addText(start: position)
        }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        let touch = touches.first
        if let movedToPosition = touch?.location(in: imageViewDraw)
        {
            draw(start: lastPosition, stop: movedToPosition)
            lastPosition = movedToPosition
        }
    }

    
    func draw(start: CGPoint, stop: CGPoint)
    {
        //begin a graphic context
        UIGraphicsBeginImageContext(imageViewDraw.frame.size)
        //draw the existing image into this context
        imageViewDraw.image?.draw(in: imageViewDraw.bounds)
        
        //avoid use ?
        guard let context = UIGraphicsGetCurrentContext() else {
            return
        }
        
        context.move(to: start)
        context.addLine(to: stop)
        context.strokePath()
        
        //finally
        imageViewDraw.image = UIGraphicsGetImageFromCurrentImageContext() //sets the imageview
        UIGraphicsEndImageContext()
        
    }
    
    func addText(start: CGPoint)
    {
        //begin a graphic context
        UIGraphicsBeginImageContext(imageViewDraw.frame.size)
        //draw the existing image into this context
        imageViewDraw.image?.draw(in: imageViewDraw.bounds)
        
        let attributes:[NSAttributedString.Key: Any] =
        [
            .font: UIFont.systemFont(ofSize: 50.0),
            .foregroundColor: UIColor.blue
        ]
        
        let string = NSAttributedString(string: "hello", attributes: attributes)
        string.draw(at: start)
        
        //finally
        imageViewDraw.image = UIGraphicsGetImageFromCurrentImageContext() //sets the imageview
        UIGraphicsEndImageContext()
    }
}

extension UIImage
{
    func resizeImage(newWidth: CGFloat) -> UIImage
    {
        //new height
        let newHeight = newWidth * (self.size.height/self.size.width)
        UIGraphicsBeginImageContext(CGSize(width: newWidth, height: newHeight))
        self.draw(in: CGRect(x: 0, y: 0, width: newWidth, height: newHeight))
        
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return newImage ?? UIImage()
    }
    /*
     @IBAction func sendMail(_ sender: Any)
     {
     if MFMailComposeViewController.canSendMail()
     {
     let mailVC = MFMailComposeViewController()
     mailVC.delegate = self
     mailVC.setCcRecipients(["jackievuong@live.dk"])
     mailVC.setSubject("image to you !!")
     mailVC.setMessageBody("hello there", isHTML: false)
     let image = imageviewShowPic.image?.resizeImageMyVersion(newWidth: 200)
     if let imageD = image?.pngData()
     {
     let imageData = imageD as NSData
     mailVC.addAttachmentData(imageData as Data, mimeType: "image/png", fileName: "i.png")
     }
     self.present(mailVC, animated: true, completion: nil)
     }
     }
     
     func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?)
     {
     controller.dismiss(animated: true, completion: nil)
     }*/
}
