//
//  ViewController.swift
//  fotodemo
//
//  Created by admin on 05/03/2019.
//  Copyright © 2019 admin. All rights reserved.
//

import UIKit
import MessageUI

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, MFMailComposeViewControllerDelegate
{
    @IBOutlet weak var textViewAddon: UITextView!
    @IBOutlet weak var imageviewShowPic: UIImageView!
    
    let imagePicker = UIImagePickerController()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        imagePicker.delegate = self
        imagePicker.sourceType = .photoLibrary
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
       print("test")
    }

    @IBAction func capturePressed(_ sender: Any)
    {
        print("capture pressed")
        self.present(imagePicker, animated: true, completion: nil)
        
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any])
    {
        
        if let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage
        {
            //print("received image \(image.size)")
            imageviewShowPic.image = textToImage(drawText: textViewAddon.text, inImage: image, atPoint: CGPoint.init(x: 500, y: 600))
            
            //imageviewShowPic.image = image.resizeImageMyVersion(newWidth: 150)
            imageviewShowPic.contentMode = .scaleAspectFit
            
        }
        //print("received image \(image?.size)")
        
        
        picker.dismiss(animated: true, completion: nil)
    }
    
    func textToImage(drawText text: String, inImage image: UIImage, atPoint point: CGPoint) -> UIImage
    {
        //styling
        let textColor = UIColor.white
        let textFont = UIFont(name: "Helvetica Bold", size: 300)!
        
        let scale = UIScreen.main.scale
        UIGraphicsBeginImageContextWithOptions(image.size, false, scale)
        
        //sets the styling
        let textFontAttributes = [
            NSAttributedString.Key.font: textFont,
            NSAttributedString.Key.foregroundColor: textColor,
            ] as [NSAttributedString.Key : Any]
        
        //Put the image into a rectangle as large as the original image
        image.draw(in: CGRect(origin: CGPoint.zero, size: image.size))
        
        //create rectangle where the text will be drawed
        let rect = CGRect(origin: point, size: image.size)
        text.draw(in: rect, withAttributes: textFontAttributes)
        
        //create a new image
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return newImage!
    }
    
    @IBAction func sendToMail(_ sender: Any)
    {
        if MFMailComposeViewController.canSendMail()
        {
            let mailVC = MFMailComposeViewController()
            mailVC.delegate = self
            mailVC.setToRecipients(["jackievuong@live.dk"])
            mailVC.setSubject("image to you !!")
            mailVC.setMessageBody("hello there", isHTML: false)
            let image = imageviewShowPic.image?.resizeImageMyVersion(newWidth: 200)
            if let imageD = image?.pngData()
            {
                let imageData = imageD as NSData
                mailVC.addAttachmentData(imageData as Data, mimeType: "image/png", fileName: "i.png")
            }
            self.present(mailVC, animated: true, completion: nil)
        }
    }
    
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?)
    {
        controller.dismiss(animated: true, completion: nil)
    }
    
}

extension UIImage
{
    func resizeImageMyVersion(newWidth: CGFloat) -> UIImage
    {
        //new height
        let newHeight = newWidth * (self.size.height/self.size.width)
        UIGraphicsBeginImageContext(CGSize(width: newWidth, height: newHeight))
        self.draw(in: CGRect(x: 0, y: 0, width: newWidth, height: newHeight))
        
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return newImage ?? UIImage()
    }
}

