//
//  ViewController.swift
//  MuseumAR
//
//  Created by admin on 07/05/2019.
//  Copyright © 2019 admin. All rights reserved.
//

//1. delegate

import UIKit
import ARKit

class ViewController: UIViewController, ARSKViewDelegate
{
    
    @IBOutlet weak var arskView: ARSKView!
    let configuration = ARWorldTrackingConfiguration()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        arskView.delegate = self
        arskView.showsFPS = true
        if let scene = SKScene(fileNamed: "MyScene")
        {
            arskView.presentScene(scene)
        }
        
        //set up configuration
        guard let refercenceImages = ARReferenceImage.referenceImages(inGroupNamed: "AR Resources", bundle: nil)
        else
        {
            fatalError("No images found for ARWorldTrackingConfiguration")
        }
        
        configuration.detectionImages = refercenceImages
        arskView.session.run(configuration)
    }
    
    @IBAction func returned(segue:UIStoryboard)
    {
        
    }
    
    
    override func viewWillAppear(_ animated: Bool)
    {
        arskView.session.run(configuration)
    }
    
    override func viewWillDisappear(_ animated: Bool)
    {
        arskView.session.pause()
    }

    func view(_ view: ARSKView, nodeFor anchor: ARAnchor) -> SKNode?
    {
        if let imageAnchor = anchor as? ARImageAnchor,
           let referenceImageName = imageAnchor.referenceImage.name
        {
            print("Found image named \(referenceImageName)")
            performSegue(withIdentifier: "seg1", sender: self)
        }
        
        return nil
    }

}

