//
//  ViewController.swift
//  ARCdemo
//
//  Created by admin on 12/04/2019.
//  Copyright © 2019 admin. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "show red", style: .plain, target: self, action: #selector(handleShowRedController))
        
        let timer = Timer.scheduledTimer(withTimeInterval: 3, repeats: false)
        {
            (timer) in
            let nc = NotificationCenter.default
            nc.post(name: NSNotification.Name(rawValue: "someName"), object: nil)
        }
    }
    
    @objc func handleShowRedController()
    {
        navigationController?.pushViewController(RedController(), animated: true)
    }
}

class RedController: UITableViewController
{
    deinit {
        print("RedController just deinitialized")
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        tableView.backgroundColor = .red
        NotificationCenter.default.addObserver(forName: NSNotification.Name(rawValue: "someName"), object: nil, queue: .main)
        {
            //[onowned self] if you known it is not nil
            [weak self] (notification) in
            self?.showAlert()
        }
    }
    
    func showAlert()
    {
        let alertController = UIAlertController(title: "hi there", message: "whats up", preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "ok", style: .default, handler: nil))
        present(alertController,animated: true,completion: nil)
    }
}

