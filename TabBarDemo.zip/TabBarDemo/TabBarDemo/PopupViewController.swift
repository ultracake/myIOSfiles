//
//  PopupViewController.swift
//  TabBarDemo
//
//  Created by admin on 03/05/2019.
//  Copyright © 2019 admin. All rights reserved.
//

import UIKit

class PopupViewController: UIViewController
{

    var parentVC:ViewController3?
    
    @IBOutlet weak var textField: UITextField!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func savePressed(_ sender: Any)
    {
        if let link = textField.text
        {
            parentVC?.addLink(url: link)
        }
        parentVC?.dismiss(animated: true, completion: nil)
    }
    

}
