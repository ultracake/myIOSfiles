//
//  ViewController3.swift
//  TabBarDemo
//
//  Created by admin on 30/04/2019.
//  Copyright © 2019 admin. All rights reserved.
//

import UIKit

class ViewController3: UIViewController, UITableViewDelegate, UITableViewDataSource, UIPopoverPresentationControllerDelegate
{
    
    var links = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        links.append("https://www.dr.dk")
        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return links.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell1", for: indexPath)
        
        cell.textLabel?.text = links[indexPath.row]
        //cell.textLabel?.text = "note.\(indexPath.row)"
        return cell
    }
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBAction func goToBookmark(_ sender: Any)
    {
        self.tabBarController?.selectedIndex = 0
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if segue.identifier == "popupSegue"
        {
            let popVC = segue.destination as! PopupViewController
            popVC.parentVC = self // so we can call the add method
            popVC.preferredContentSize = CGSize(width: 300, height: 300) // dynamic size
            popVC.presentationController?.delegate = self
        }
        
    }
    
    func adaptivePresentationStyle(for controller: UIPresentationController) -> UIModalPresentationStyle
    {
        return UIModalPresentationStyle.none
    }
    
    func addLink(url: String)
    {
        links.append(url)
        tableView.reloadData()
    }

    
    @IBAction func saveLink(_ sender: Any)
    {
        
    }
  

}
