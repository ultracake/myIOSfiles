//
//  SecondViewController.swift
//  TabBarDemo
//
//  Created by admin on 30/04/2019.
//  Copyright © 2019 admin. All rights reserved.
//

import UIKit
import WebKit

class SecondViewController: UIViewController, WKNavigationDelegate
{
    var webView:WKWebView?
    //var name = "https://www.dr.dk"

    override func viewDidLoad()
    {
        super.viewDidLoad()
        
         //1. create URL
        let url = URL(string: myGlobal.myString)
        
        //2. load
        webView?.load(URLRequest(url: url!))
        
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        //1. create URL
        let url = URL(string: myGlobal.myString)
        
        //2. load
        webView?.load(URLRequest(url: url!))
    }

    override func loadView()
    {
        webView = WKWebView()
        webView?.navigationDelegate = self
        self.view = webView
    }

}

