//
//  ViewController.swift
//  TicTacToe
//
//  Created by admin on 29/03/2019.
//  Copyright © 2019 admin. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    var turnX = true
    var turnText = "X"
    var imageXO = UIImage(named: "tictactoeX")
    let imageRe = UIImage(named: "cake0")
    
    var clicked0 = false
    var clicked1 = false
    var clicked2 = false
    var clicked3 = false
    var clicked4 = false
    var clicked5 = false
    var clicked6 = false
    var clicked7 = false
    var clicked8 = false
    
    @IBOutlet weak var winnerText: UITextField!
    @IBOutlet weak var but0: UIButton!
    @IBOutlet weak var but1: UIButton!
    @IBOutlet weak var but2: UIButton!
    @IBOutlet weak var but3: UIButton!
    @IBOutlet weak var but4: UIButton!
    @IBOutlet weak var but5: UIButton!
    @IBOutlet weak var but6: UIButton!
    @IBOutlet weak var but7: UIButton!
    @IBOutlet weak var but8: UIButton!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
    }
    
    func checkGame()
    {
        //print("checking start")
        checkHon(imageC: imageXO!)
        checkVer(imageC: imageXO!)
        checkDia(imageC: imageXO!)
    }
    
    func checkHon(imageC: UIImage)
    {
        if but0.imageView?.image == imageC && but1.imageView?.image == imageC && but2.imageView?.image == imageC
        {
            winFreezz()
        }
        if but3.imageView?.image == imageC && but4.imageView?.image == imageC && but5.imageView?.image == imageC
        {
            winFreezz()
        }
        if but6.imageView?.image == imageC && but7.imageView?.image == imageC && but8.imageView?.image == imageC
        {
            winFreezz()
        }
    }
    
    func checkVer(imageC: UIImage)
    {
        if but0.imageView?.image == imageC && but3.imageView?.image == imageC && but6.imageView?.image == imageC
        {
            winFreezz()
        }
        if but1.imageView?.image == imageC && but4.imageView?.image == imageC && but7.imageView?.image == imageC
        {
            winFreezz()
        }
        if but2.imageView?.image == imageC && but5.imageView?.image == imageC && but8.imageView?.image == imageC
        {
            winFreezz()
        }
    }
    
    func checkDia(imageC: UIImage)
    {
        if but0.imageView?.image == imageC && but4.imageView?.image == imageC && but8.imageView?.image == imageC
        {
            winFreezz()
        }
        if but2.imageView?.image == imageC && but4.imageView?.image == imageC && but6.imageView?.image == imageC
        {
            winFreezz()
        }
    }
    
    func setTurn()
    {
        if turnX == true
        {
            turnX = false
            turnText = "O"
            imageXO = UIImage(named: "tictactoeO")
            
        }else
        {
            turnX = true
            turnText = "X"
            imageXO = UIImage(named: "tictactoeX")
        }
    }
    
    func callMyAllSelectMeth()
    {
        checkGame()
        setTurn()
    }
    
    func winFreezz()
    {
        winnerText.text = "The winner is "+turnText
        clicked0 = true
        clicked1 = true
        clicked2 = true
        clicked3 = true
        clicked4 = true
        clicked5 = true
        clicked6 = true
        clicked7 = true
        clicked8 = true
        
    }

    @IBAction func butClicked(_ sender: UIButton)
    {
        switch sender
        {
        case but0:
            if clicked0 == false
            {
                but0.setImage(imageXO, for: .normal)
                callMyAllSelectMeth()
                clicked0 = true
            }
        case but1:
            if clicked1 == false
            {
                but1.setImage(imageXO, for: .normal)
                callMyAllSelectMeth()
                clicked1 = true
            }
        case but2:
            if clicked2 == false
            {
                but2.setImage(imageXO, for: .normal)
                callMyAllSelectMeth()
                clicked2 = true
            }
        case but3:
            if clicked3 == false
            {
                but3.setImage(imageXO, for: .normal)
                callMyAllSelectMeth()
                clicked3 = true
            }
        case but4:
            if clicked4 == false
            {
                but4.setImage(imageXO, for: .normal)
                callMyAllSelectMeth()
                clicked4 = true
            }
        case but5:
            if clicked5 == false
            {
                but5.setImage(imageXO, for: .normal)
                callMyAllSelectMeth()
                clicked5 = true
            }
        case but6:
            if clicked6 == false
            {
                but6.setImage(imageXO, for: .normal)
                callMyAllSelectMeth()
                clicked6 = true
            }
        case but7:
            if clicked7 == false
            {
                but7.setImage(imageXO, for: .normal)
                callMyAllSelectMeth()
                clicked7 = true
            }
        case but8:
            if clicked8 == false
            {
                but8.setImage(imageXO, for: .normal)
                callMyAllSelectMeth()
                clicked8 = true
            }
        default:
            print("hi")
        }
    }
    
    @IBAction func restartGame(_ sender: Any)
    {
        tempRestart()
        
        //exit(0)
        //self.dismiss(animated: false, completion: nil)
        //self.presentingViewController?.dismiss(animated: false, completion: nil)
        //print("end game")
    }
    
    func tempRestart()
    {
        turnX = true
        turnText = "X"
        imageXO = UIImage(named: "tictactoeX")
        
        clicked0 = false
        clicked1 = false
        clicked2 = false
        clicked3 = false
        clicked4 = false
        clicked5 = false
        clicked6 = false
        clicked7 = false
        clicked8 = false
        
        but0.setImage(imageRe, for: .normal)
        but1.setImage(imageRe, for: .normal)
        but2.setImage(imageRe, for: .normal)
        but3.setImage(imageRe, for: .normal)
        but4.setImage(imageRe, for: .normal)
        but5.setImage(imageRe, for: .normal)
        but6.setImage(imageRe, for: .normal)
        but7.setImage(imageRe, for: .normal)
        but8.setImage(imageRe, for: .normal)
        
        winnerText.text = ""
    }
}

