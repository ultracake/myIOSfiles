//
//  ViewController.swift
//  notebook
//
//  Created by admin on 12/02/2019.
//  Copyright © 2019 admin. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    var testSwift = MyTestSwift() // non-optional
    //var testSwift2: MyTestSwift // optional
    
    
    let defualts = UserDefaults.standard
    
    @IBOutlet weak var textView: UITextView!
    @IBOutlet weak var textfield: UITextField!
    @IBOutlet weak var button1: UIButton!
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        testSwift.printHello()
        // ? means it will call the method If there is a value
        // otherwise it will quietly discard the statement.
        
        // ! means it will call the method If there is a value
        // if there is no value, the program will crash.
        
        if let message = defualts.string(forKey: "message")
        {
            textView.text = message
        }
        else
        {
            textView.text = "empty"
        }
    }
    
    func saveText()
    {
        defualts.set(textView.text, forKey: "message")
    }

    @IBAction func tryMe(_ sender: Any)
    {
        saveText()
        
        //print("viewWillDisappear")
        //button1.isHidden = true
    }
    
    @IBAction func changeColor(_ sender: Any)
    {
        view.backgroundColor = UIColor.blue
    }
    
    
    
}

