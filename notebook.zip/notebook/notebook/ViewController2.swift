//
//  ViewController2.swift
//  notebook
//
//  Created by admin on 15/02/2019.
//  Copyright © 2019 admin. All rights reserved.
//

import UIKit

class ViewController2: UIViewController
{
    
    @IBOutlet weak var textView: UITextField!
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if let destination = segue.destination as? ViewController3
        {
            destination.name = textView.text ?? ""
            //destination.name = "some text"
        }
    }
    @IBAction func goPressed(_ sender: Any)
    {
        performSegue(withIdentifier: "segue2" , sender: self)
        print("goPressed")
    }
    
    
   

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
