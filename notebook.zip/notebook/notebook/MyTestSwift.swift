//
//  testSwift.swift
//  notebook
//
//  Created by admin on 15/02/2019.
//  Copyright © 2019 admin. All rights reserved.
//

import Foundation
class MyTestSwift
{
    func printHello()
    {
        print("hello world")
    }
    
    func printThis()
    {
        print("haha nice day")
    }

}
