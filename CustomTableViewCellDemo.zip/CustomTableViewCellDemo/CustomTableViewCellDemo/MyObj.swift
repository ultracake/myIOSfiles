//
//  mytest.swift
//  CustomTableViewCellDemo
//
//  Created by admin on 28/03/2019.
//  Copyright © 2019 admin. All rights reserved.
//

import Foundation
import UIKit

class MyObj
{
    var myText = ""
    var myImage = UIImage(named: "cake0")
    
    init(inText:String, inImage:UIImage)
    {
        myText = inText
        myImage = inImage
    }
    
    func getMytest() -> String
    {
        return myText
    }
}
