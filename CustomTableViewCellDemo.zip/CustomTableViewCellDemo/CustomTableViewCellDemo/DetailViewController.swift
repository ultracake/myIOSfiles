//
//  DetailViewController.swift
//  CustomTableViewCellDemo
//
//  Created by admin on 26/03/2019.
//  Copyright © 2019 admin. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController
{
    var currentIndex = -1 //variable check

    @IBOutlet weak var textFieldInput: UITextView!
    override func viewDidLoad()
    {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        //textFieldInput.text = myNotesGlobal.objList[currentIndex].myText
        textFieldInput.text = myNotesGlobal.notes[currentIndex]
    }
    
    /*
    override func viewWillDisappear(_ animated: Bool)
    {
        myNotesGlobal.notes[currentIndex] = textFieldInput.text!
        myNotesGlobal.saveNotes()
    }*/
    
    func saveText()
    {
        //myNotesGlobal.objList[currentIndex].myText = textFieldInput.text
        myNotesGlobal.notes[currentIndex] = textFieldInput.text
    }
    
    @IBAction func saveNote(_ sender: Any)
    {
        saveText()
        myNotesGlobal.saveNotes()
    }

    @IBAction func deleteThisNote(_ sender: Any)
    {
        myNotesGlobal.deleteNote(id: currentIndex)
    }
}
