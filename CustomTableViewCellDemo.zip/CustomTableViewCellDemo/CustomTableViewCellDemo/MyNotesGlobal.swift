//
//  MyNoteClass.swift
//  CustomTableViewCellDemo
//
//  Created by admin on 26/03/2019.
//  Copyright © 2019 admin. All rights reserved.
//

import Foundation
import UIKit

class MyNotesGlobal
{
    var objList = [MyObj]()
    var notes = [String]()
    let defualts = UserDefaults.standard
    
    func saveNotes()
    {
        //defualts.set(objList, forKey: "myObj")
        defualts.set(notes, forKey: "notes")
        
    }
    /*
    func loadObjList()
    {
        if let objFromStorage = defualts.array(forKey: "myObj") as? [MyObj]
        {
            objList = objFromStorage
        }
        else
        {
            objList = [MyObj]()
            var obj = MyObj(inText: "hi", inImage: UIImage(named: "cake0")!)
            objList.append(obj)
        }
    }*/
    
    func loadNotes()
    {
        if let notesFromStorage = defualts.array(forKey: "notes") as? [String]
        {
            notes = notesFromStorage
        }
        else
        {
            notes = [String]()
            notes.append("empty note")
        }
    }
    
    func deleteNote(id: Int)
    {
        //MyReset()
        
        var tempStr = [String]()
        var count = 0
        
        for note in notes
        {
            if count != id
            {
                tempStr.append(note)
            }
            count += 1
        }
        notes = tempStr
        saveNotes()
    }
    
    func MyReset()
    {
        //for resest
        notes.removeAll()
        //notes.remove(at: id)
        saveNotes()
    }
}
