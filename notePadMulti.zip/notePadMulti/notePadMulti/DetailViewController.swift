//
//  DetailViewController.swift
//  notePadMulti
//
//  Created by admin on 19/02/2019.
//  Copyright © 2019 admin. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController
{
    
    var currentIndex = -1 //variable check
    
    @IBOutlet weak var textviewNote: UITextView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        textviewNote.text = global.notes[currentIndex]
    }
    
    override func viewWillDisappear(_ animated: Bool)
    {
        global.notes[currentIndex] = textviewNote.text
        global.saveNotes()
    }
    
    func saveText()
    {
        global.notes[currentIndex] = textviewNote.text
    }

    @IBAction func saveNote(_ sender: Any)
    {
        saveText()
        global.saveNotes()
    }

    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
