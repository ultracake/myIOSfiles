//
//  ViewController.swift
//  ARaddNodeDemo
//
//  Created by admin on 10/05/2019.
//  Copyright © 2019 admin. All rights reserved.
//

import UIKit
import ARKit

class ViewController: UIViewController, ARSCNViewDelegate
{

    @IBOutlet weak var arscnView: ARSCNView!
    
    var imageTrackConfig:ARImageTrackingConfiguration?
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        arscnView.delegate = self
        
        let scene = SCNScene()
        arscnView.scene = scene
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        
        if let config = imageTrackConfig
        {
            arscnView.session.run(config)
        }
    }

    func setupImageDetection()
    {
        imageTrackConfig = ARImageTrackingConfiguration()
        
        guard let refImages = ARReferenceImage.referenceImages(inGroupNamed: "AR Resources", bundle: nil)
        else
        {
            print("no image")
            return
        }
        imageTrackConfig?.trackingImages = refImages
    }

    func renderer(_ renderer: SCNSceneRenderer, didAdd node: SCNNode, for anchor: ARAnchor)
    {
        print("found image \(anchor.name)")
        if let anchor = anchor as? ARImageAnchor
        {
            addNode(anchor: anchor, node: node)
        }
    }
    
    func addNode(anchor: ARImageAnchor, node:SCNNode)
    {
        if let newNode = getGraphicNode(size: anchor.referenceImage.physicalSize)
        {
            node.addChildNode(newNode)
            node.opacity = 1 // ??
        }
    }
    
    func getGraphicNode(size:CGSize) -> SCNNode?
    {
        //1. get some material
        let material = SCNMaterial()
        material.diffuse.contents = UIImage(named: "cake1")
        
        //2. get a plane
        let plane = SCNPlane(width: size.width, height: size.height)
        plane.materials = [material]
        
        //3. get a node
        let node = SCNNode(geometry: plane)
        
        
        return node
    }
}

