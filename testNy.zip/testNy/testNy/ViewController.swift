//
//  ViewController.swift
//  testNy
//
//  Created by admin on 08/02/2019.
//  Copyright © 2019 admin. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    @IBAction func returnedFromVC(segue:UIStoryboardSegue)
    {
        print("Hello")
    }
    
    func test1(variableTest: Int) -> Int
    {
        return variableTest
        <#function body#>
    }


}

