//
//  GetNoteViewController.swift
//  FirestoreDemo
//
//  Created by admin on 15/03/2019.
//  Copyright © 2019 admin. All rights reserved.
//

import UIKit
import FirebaseAuth

class GetNoteViewController: UIViewController
{

    @IBOutlet weak var textViewDis: UITextView!
    @IBOutlet weak var textfieldId: UITextField!
    
    @IBOutlet weak var textFID2: UITextField!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        
        // Do any additional setup after loading the view.
    }
    @IBAction func logoutBut(_ sender: Any)
    {
        do
        {
            try Auth.auth().signOut()
            print("logout succssfully")
            self.performSegue(withIdentifier: "seg3", sender: self)
        }
        catch
        {
            print("some error \(error.localizedDescription)")
        }
    }
    
    @IBAction func getNoteById(_ sender: Any)
    {
        let keyword = textfieldId.text
        for note in fR.notes
        {
            if note.text.contains(keyword!) == true
            {
                textViewDis.text = note.text
            }
        }
    }
    
    @IBAction func getNoteByActuelleID(_ sender: Any)
    {
        let txtID = textFID2.text
        textViewDis.text = fR.notes[1].text
    }
}
