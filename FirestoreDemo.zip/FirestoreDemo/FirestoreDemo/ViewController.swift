//
//  ViewController.swift
//  FirestoreDemo
//
//  Created by admin on 12/03/2019.
//  Copyright © 2019 admin. All rights reserved.
//

import UIKit
import FirebaseAuth

let fR = firebaseRepo()
class ViewController: UIViewController
{
    
    @IBOutlet weak var textView: UITextView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        print(fR.getStatus())
        //fR.viewController!.self
        
    }
    @IBAction func createNote(_ sender: Any)
    {
        if let txt = textView.text
        {
            fR.noteCollection.document().setData(["text": txt])
            {
                error in if error != nil
                {
                    print("some errror)")
                }
            }
        }
    }

    @IBAction func logoutBut(_ sender: Any)
    {
        do
        {
            try Auth.auth().signOut()
            print("logout succssfully")
            self.performSegue(withIdentifier: "seg2", sender: self)
        }
        catch
        {
            print("some error \(error.localizedDescription)")
        }
    }
    
}

