//
//  note.swift
//  FirestoreDemo
//
//  Created by admin on 12/03/2019.
//  Copyright © 2019 admin. All rights reserved.
//

import Foundation
import Firebase

class note
{
    var text:String
    
    init(t:String)
    {
        text = t
    }
}
