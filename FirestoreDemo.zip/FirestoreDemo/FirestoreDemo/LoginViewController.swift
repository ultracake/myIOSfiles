//
//  LoginViewController.swift
//  FirestoreDemo
//
//  Created by admin on 15/03/2019.
//  Copyright © 2019 admin. All rights reserved.
//

import UIKit
import FirebaseAuth

class LoginViewController: UIViewController
{

    @IBOutlet weak var Password: UITextField!
    @IBOutlet weak var Username: UITextField!
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

    }
    
    @IBAction func loginBut(_ sender: Any)
    {
        if let usr = Username.text, let pwd = Password.text
        {
            Auth.auth().signIn(withEmail: usr, password: pwd)
            {
                (result, error) in
                if error == nil 
                {
                    print("login success")
                    self.performSegue(withIdentifier: "segue1", sender: self)
                }else
                {
                    print("some error\(error.debugDescription)")
                }
            }
        }
    }

}
