//
//  firebaseRepo.swift
//  FirestoreDemo
//
//  Created by admin on 12/03/2019.
//  Copyright © 2019 admin. All rights reserved.
//

import Foundation
import Firebase

class firebaseRepo
{
    var notes = [note]()
    let noteCollection = Firestore.firestore().collection("notes")
    public var viewController:ViewController?
    
    init()
    {
        startNoteListner()
    }
    
    func startNoteListner()
    {
        noteCollection.addSnapshotListener{(snapshot,error) in
            //code here vill be executed when ever there is a change in firebase
            print("received new snapshort")
            
            for document in snapshot!.documents
            {
                if let text = document.data()["text"] as? String
                {
                    let noteF = note(t:text)
                    self.notes.append(noteF)
                    print("received \(text)")
                }
            }
            //self.viewController?.reloadTableSomething()
        }
    }
    
    func getStatus() -> String
    {
        return noteCollection.collectionID
    }
}
