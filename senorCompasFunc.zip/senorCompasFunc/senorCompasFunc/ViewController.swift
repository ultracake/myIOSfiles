//
//  ViewController.swift
//  senorCompasFunc
//
//  Created by admin on 05/04/2019.
//  Copyright © 2019 admin. All rights reserved.
//

import UIKit
import CoreLocation

class ViewController: UIViewController, CLLocationManagerDelegate
{
    
    @IBOutlet weak var imageView: UIImageView!
    
    var locationManager = CLLocationManager()
    let home = CLLocationCoordinate2D(latitude: 55.688, longitude: 12.44555)
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        //locationManager.startUpdatingHeading()
        locationManager.startUpdatingLocation()
    }
    
    //which direction (retning)
    func locationManager(_ manager: CLLocationManager, didUpdateHeading newHeading: CLHeading)
    {
        print("heading: ", newHeading.trueHeading)
        
        let rad = degreesToRadians(degrees: newHeading.trueHeading)
        UIView.animate(withDuration: 0.5) //seconds
        {
            print("heading in radians:" , rad )
            self.imageView.transform = CGAffineTransform(rotationAngle: CGFloat(rad))
        }
        
        
    }
    
    func getBearing(lat1: Double, long1: Double, lat2:Double, long2:Double) -> Double
    {
        let dlon = (long2 - long1)
        let y = sin(dlon) * cos(lat2)
        let x = cos(lat1) * sin(lat2) - sin(lat1) * cos(lat2) * cos(dlon)
        var brng = atan2(y,x)
        
        brng = radiansToDegrees(rad: brng)
        brng = (brng + 360.0).truncatingRemainder(dividingBy: 360.0)
        brng = 360 - brng
        
        return brng
    }
    
    func radiansToDegrees(rad:Double) -> Double
    {
        return 180 * rad / Double.pi
    }
    
    func degreesToRadians(degrees: Double) -> Double
    {
        return Double.pi * degrees / 180.0
    }

    //position 
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation])
    {
        //print("location: ", locations.first?.coordinate)
        let loc = locations.first?.coordinate
        let bearing = getBearing(lat1: loc!.latitude, long1: loc!.longitude, lat2: home.latitude, long2: home.longitude)
        print("bearing: ", bearing)
        
    }

}

