//
//  FirebaseService.swift
//  FileToFirestore
//
//  Created by admin on 22/03/2019.
//  Copyright © 2019 admin. All rights reserved.
//

import Foundation
import Firebase
import FirebaseStorage

class FirebaseService
{
    //database
    let notesCollection = Firestore.firestore().collection("notes")
    
    //storage
    let storage = Storage.storage() //service
    var storageRef:StorageReference? = nil
    
    var notes = [Note]()
    
    func uploadImage(image:UIImage, note:Note, document:DocumentReference)
    {
        let data = image.jpegData(compressionQuality: 1.0)
        let imageRef = storageRef?.child(note.imageName) //adds a child to current location in storage
        imageRef?.putData(data! , metadata: nil, completion: {metadata, error in
            //this runs After Firebase is done saving, or whatever it does
            if error != nil
            {
                print("fail to upload\(error.debugDescription)")
            }
            else
            {
                print("success opload")
                // let image = UIImage(data: data!)
                self.writeTextToDB(note: note
                    , document: document)
            }
        })
    }
    
    func writeTextToDB(note:Note, document:DocumentReference)
    {
        document.setData(["text":note.text, "imageName": note.imageName]){error in
            if error != nil
            {
                print("error writing to DB")
            }
            else
            {
                print("success in writting to DB")
            }
        }
    }
    
    func startNoteListner()
    {
        notesCollection.addSnapshotListener{(snapshot,error) in
            //code here vill be executed when ever there is a change in firebase
            print("received new snapshort")
            
            for document in snapshot!.documents
            {
                if let text = document.data()["text"] as? String
                {
                    if let imageName = document.data()["imageName"] as? String{
                    let noteF = Note(text: text, imageName: imageName)
                    self.notes.append(noteF)
                        print("received \(text)")
                        
                    }
                }
            }

            DispatchQueue.main.async
            {
                for note in self.notes
                {
                    self.downloadImage(fileName: note.imageName, note: note)
                }
            }
            
        }
    }
    
    func downloadImage(fileName:String,note:Note)
    {
        let imageRef = storage.reference(withPath: fileName)
        imageRef.getData(maxSize: 5000000, completion: {(data,error) in
            if error != nil
            {
                print("fail download")
            }
            else
            {
                print("success download")
                let image = UIImage(data: data!)
                note.image = image
                print("image discription: \(image?.debugDescription)")
            }
        })
    }
    
}
