//
//  Note.swift
//  FileToFirestore
//
//  Created by admin on 22/03/2019.
//  Copyright © 2019 admin. All rights reserved.
//
import UIKit

class Note
{
    var text:String
    var imageName:String
    var image:UIImage?
    
    init(text:String, imageName:String, image:UIImage? = nil)
    {
        self.text = text
        self.imageName = imageName
    }
}
