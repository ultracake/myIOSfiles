//
//  ExtraViewController.swift
//  FileToFirestore
//
//  Created by admin on 22/03/2019.
//  Copyright © 2019 admin. All rights reserved.
//

import UIKit
import FirebaseStorage

let fS = FirebaseService()
class ExtraViewController: UIViewController
{

    @IBOutlet weak var imageView3: UIImageView!
    @IBOutlet weak var textViewInsert: UITextView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        fS.storageRef = fS.storage.reference() //the root for all files
        fS.startNoteListner()
        // Do any additional setup after loading the view.
        
       
    }
    
    
    @IBAction func downloadImage(_ sender: Any)
    {
    }
    
    @IBAction func saveData(_ sender: Any)
    {
        let document = fS.notesCollection.document() //get unique ID
        let note = Note(text: textViewInsert.text, imageName: "\(document.documentID).jpg")
        if let image = imageView3.image
        {
            fS.uploadImage(image: image, note:note, document: document)
        }
    }
    
   

}
