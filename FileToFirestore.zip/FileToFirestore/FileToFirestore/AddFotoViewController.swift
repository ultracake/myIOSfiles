//
//  AddFotoViewController.swift
//  FileToFirestore
//
//  Created by admin on 20/03/2019.
//  Copyright © 2019 admin. All rights reserved.
//

import UIKit
import FirebaseStorage

class AddFotoViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate
{
    var storage:Storage?
    var storageRef:StorageReference?
    let imagePicker = UIImagePickerController()

    @IBOutlet weak var textInsertName: UITextField!
    @IBOutlet weak var textFieldInput: UITextField!
    @IBOutlet weak var imageViewAdd: UIImageView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        imagePicker.delegate = self
        imagePicker.sourceType = .photoLibrary
        
        storage = Storage.storage()          //this is the storage service
        storageRef = storage!.reference()    //this is the root for all the files

    }
    
    @IBAction func selectImage(_ sender: Any)
    {
        self.present(imagePicker, animated: true, completion: nil)
    }
    
    @IBAction func uploadToFirebase(_ sender: Any)
    {
        if let image = imageViewAdd.image
        {
            print("try oploading")
            uploadImage(image: image, filename: textInsertName.text!)
        }
    }
    
    func uploadImage(image:UIImage, filename:String)
    {
        let data = image.jpegData(compressionQuality: 1.0)
        let imageRef = storageRef?.child(filename)
        imageRef?.putData(data! , metadata: nil, completion: {metadata, error in
            //this part runs After Firebase is done saving, or whatever it does
            if error != nil
            {
                print("fail to upload\(error.debugDescription)")
            }
            else
            {
                print("success opload")
            }
        })
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any])
    {
        
        if let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage
        {
            //print("received image \(image.size)")
            //imageViewAdd.image = textToImage(drawText: textFieldInput.text!, inImage: image, atPoint: CGPoint.init(x: 500, y: 600))
            imageViewAdd.image = image
            //imageviewShowPic.image = image.resizeImageMyVersion(newWidth: 150)
            imageViewAdd.contentMode = .scaleAspectFit
            
        }
        //print("received image \(image?.size)")
        
        
        picker.dismiss(animated: true, completion: nil)
    }
    
    func textToImage(drawText text: String, inImage image: UIImage, atPoint point: CGPoint) -> UIImage
    {
        //styling
        let textColor = UIColor.white
        let textFont = UIFont(name: "Helvetica Bold", size: 300)!
        
        let scale = UIScreen.main.scale
        UIGraphicsBeginImageContextWithOptions(image.size, false, scale)
        
        //sets the styling
        let textFontAttributes = [
            NSAttributedString.Key.font: textFont,
            NSAttributedString.Key.foregroundColor: textColor,
            ] as [NSAttributedString.Key : Any]
        
        //Put the image into a rectangle as large as the original image
        image.draw(in: CGRect(origin: CGPoint.zero, size: image.size))
        
        //create rectangle where the text will be drawed
        let rect = CGRect(origin: point, size: image.size)
        text.draw(in: rect, withAttributes: textFontAttributes)
        
        //create a new image
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return newImage!
    }


}
