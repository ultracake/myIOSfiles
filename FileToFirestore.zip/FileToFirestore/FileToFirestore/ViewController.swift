//
//  ViewController.swift
//  FileToFirestore
//
//  Created by admin on 19/03/2019.
//  Copyright © 2019 admin. All rights reserved.
//

import UIKit
import FirebaseStorage

class ViewController: UIViewController
{
    var storage:Storage?
    var storageRef:StorageReference?

    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var textInput: UITextField!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        storage = Storage.storage()          //this is the storage service
        storageRef = storage!.reference()    //this is the root for all the files
       
        /*if let newImage = UIImage(named: textInput.text!)
        {
            uploadImage(image: newImage, filename: textInput.text!)
        }*/
        if let dogImage = UIImage(named: "dog")
        {
            uploadImage(image: dogImage, filename: "dog")
        }
        
    }
    
    func uploadImage(image:UIImage, filename:String)
    {
        let data = image.jpegData(compressionQuality: 1.0)
        let imageRef = storageRef?.child(filename)
        imageRef?.putData(data! , metadata: nil, completion: {metadata, error in
            //this runs After Firebase is done saving, or whatever it does
            if error != nil
            {
                print("fail to upload\(error.debugDescription)")
            }
            else
            {
                print("success opload")
            }
        })
    }

    @IBAction func downloadImagepressed(_ sender: Any)
    {
        let imageRef = storage?.reference(withPath: textInput.text!)
        imageRef?.getData(maxSize: 5000000, completion: {(data,error) in
            if error != nil
            {
                print("fail download")
            }
            else
            {
                print("success download")
                let image = UIImage(data: data!)
                self.imageView.image = image
                self.imageView.contentMode = .scaleAspectFit
            }
        })
    }
    
}

