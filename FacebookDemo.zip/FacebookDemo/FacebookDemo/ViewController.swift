//
//  ViewController.swift
//  FacebookDemo
//
//  Created by admin on 26/04/2019.
//  Copyright © 2019 admin. All rights reserved.
//

import UIKit
import FacebookLogin
import FBSDKLoginKit

class ViewController: UIViewController, FBSDKLoginButtonDelegate
{
    @IBOutlet weak var checkLabel: UILabel!
    @IBOutlet weak var myImageView: UIImageView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        let loginButton = LoginButton(readPermissions: [ .publicProfile, .email])
       
        
        loginButton.center = view.center
        self.view.addSubview(loginButton)
        
        
        if FBSDKAccessToken.current() != nil
        {
            self.checkLabel.text = "Logged in"
        }else
        {
            self.checkLabel.text = "Not log in "
        }
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        if FBSDKAccessToken.current() != nil
        {
            self.checkLabel.text = "Logged in"
            DispatchQueue.main.async
            {
                    self.performSegue(withIdentifier: "logSegue", sender: self)
            }
        }else
        {
            self.checkLabel.text = "Not logged in "
        }
    }
    
    @IBAction func facebookLogin(_ sender: Any)
    {
        
    }
    
    func loginButton(_ loginButton: FBSDKLoginButton!, didCompleteWith result: FBSDKLoginManagerLoginResult!, error: Error!)
    {
        if error != nil
        {
            self.checkLabel.text = error.localizedDescription
        } else if result.isCancelled
        {
            self.checkLabel.text = "User cancelled login"
        } else
        {
            self.checkLabel.text = "You´re login"
            DispatchQueue.main.async
                {
                self.performSegue(withIdentifier: "logSegue", sender: self)
            }
            
        }
    }
    
    func loginButtonDidLogOut(_ loginButton: FBSDKLoginButton!)
    {
        self.checkLabel.text = "you´re now logout"
    }
    
    
    //let manager = LoginManager
    //manager.logOut()
    //let auth = Auth.auth
    //auth.Signout
   
    /*
    func showUserInfo(token: AccessToken)
    {
        //1. build a query
        let connection = GraphRequestConnection()
        let request = GraphRequest(graphPath: "/me", parameters: ["fields":"id, email, picture.type(large)"]), accessToken: token, httpMethod: .GET, apiVersion: .defaultVersion)
        connection.add(request)
        {
            response, result in
            switch result {
            case .success(response: let response):
                print("response: \(response)")
                if let picture = response.dictionaryValue!["picture"] as? [String:Any],
                let data = picture["data"] as? [String:Any],
                let url = data["url"] as? String
                {
                    let urlObject = URL(string: url)
                    self.UIimage.load(url: urlObject)
                    print(url)
                }
                break
            case .failed(let error):
                print("error \(error.localizedDescription)")
                break
            }
        }
        
        //2. execute the query
        connection.start()
    }*/
    
}

extension UIImageView
{
    func load(url:URL)
    {
        DispatchQueue.global().async
        { [weak self] in
            if let data = try? Data(contentsOf: url)
            {
                if let image = UIImage(data: data)
                {
                    DispatchQueue.main.async
                    {
                        self?.image = image
                    }
                }
            }
        }
    }
}

enum Days
{
    case monday
    case tuesday
}

