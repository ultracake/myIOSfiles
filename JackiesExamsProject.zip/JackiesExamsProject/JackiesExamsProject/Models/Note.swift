//
//  Note.swift
//  JackiesExamsProject
//
//  Created by admin on 24/05/2019.
//  Copyright © 2019 admin. All rights reserved.
//

import Foundation
import Firebase

class Note
{
    var note:String
    var weblink:String
    var votes:Int
    var background:Int
    
    init(txt:String, web:String, vot:Int, back:Int)
    {
        note = txt
        weblink = web
        votes = vot
        background = back
    }
}
