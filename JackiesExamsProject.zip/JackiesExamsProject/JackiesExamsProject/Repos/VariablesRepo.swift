//
//  VariablesRepo.swift
//  JackiesExamsProject
//
//  Created by admin on 08/06/2019.
//  Copyright © 2019 admin. All rights reserved.
//

import Firebase

class VariablesRepo
{
    var sizeOfStoredImages = 0
    let refVar = Firestore.firestore().collection("Variables")
    
    init()
    {
        startVariablesListner()
    }
    
    func startVariablesListner()
    {
        refVar.addSnapshotListener{(snapshot,error) in
            //code here vill be executed when ever there is a change in firebase
            for document in snapshot!.documents
            {
                //print("received new snapshort")
                if let currentSize = document.data()["size"] as? Int
                {
                    self.sizeOfStoredImages = currentSize
                }
            }
        }
    }
    
    func createVarSize(name:String)
    {
        //use the ref from Repo class
        refVar.document(name).setData([
            "size": 0])
        {
            error in if error != nil
            {
                print("some error")
            }
        }
    }
    
    func increaseSize(name:String)
    {
        refVar.document(name).updateData([
            "size": sizeOfStoredImages+1])
        { err in
            if let err = err
            {
                print("Error updating document: \(err)")
            } else
            {
                print("Document successfully updated")
            }
        }
    }
}
