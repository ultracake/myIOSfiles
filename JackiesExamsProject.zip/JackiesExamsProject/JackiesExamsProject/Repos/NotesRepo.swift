//
//  FirebaseRepo.swift
//  JackiesExamsProject
//
//  Created by admin on 21/05/2019.
//  Copyright © 2019 admin. All rights reserved.
//

import Firebase

class NotesRepo
{
    var notesList = [Note]()
    let refNotes = Firestore.firestore().collection("Notes")
    
    init()
    {
        startNoteListner()
    }
   
    func startNoteListner()
    {
        refNotes.addSnapshotListener{(snapshot,error) in
            //code here vill be executed when ever there is a change in firebase
            self.notesList = []
            for document in snapshot!.documents
            {
                //print("received new snapshort")
                if let note = document.data()["note"] as? String,
                   let weblink = document.data()["link"] as? String,
                   let votes = document.data()["votes"] as? Int,
                   let background = document.data()["background"] as? Int
                {
                    let noteFromDB = Note(txt:note, web:weblink, vot:votes, back:background)
                    self.notesList.append(noteFromDB)
                }
            }
        }
    }
    
    func createNote(noteText:String, newlink:String)
    {
        //use the ref from Repo class
        refNotes.document(newlink).setData([
            "note": noteText,
            "link":newlink,
            "votes": 0,
            "background":0])
        {
            error in if error != nil
            {
                print("some error")
            }
        }
    }
    
    func deleteNote(keyName:String)
    {
        //use the ref from Repo class
        refNotes.document(keyName).delete()
        { err in
            if let err = err
            {
                print("Error removing document: \(err)")
            } else
            {
                print("Document successfully removed!")
            }
        }
    }
    
    func saveChanges(currentNote: Note)
    {
        refNotes.document(currentNote.weblink).updateData([
            "note": currentNote.note,
            "votes": currentNote.votes,
            "background":currentNote.background])
        { err in
            if let err = err
            {
                print("Error updating document: \(err)")
            } else
            {
                print("Document successfully updated")
            }
        }
    }
    
}
