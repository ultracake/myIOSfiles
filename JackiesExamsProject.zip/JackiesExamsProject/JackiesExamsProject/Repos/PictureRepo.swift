//
//  PictureRepo.swift
//  JackiesExamsProject
//
//  Created by admin on 07/06/2019.
//  Copyright © 2019 admin. All rights reserved.
//

import UIKit
import FirebaseStorage

class PictureRepo
{
    var storage:Storage?
    var storageRef:StorageReference?
    
    var currentImage:UIImage
    
    init()
    {
        storage = Storage.storage()          //this is the storage service
        storageRef = storage!.reference()    //this is the root for all the files
        
        currentImage = UIImage(named: "cake\(0)")!
    }
    
    func downloadImage(name:String) -> UIImage
    {
        let imageRef = storage?.reference(withPath: name)
        imageRef?.getData(maxSize: 50000000, completion: {(data,error) in
            if error != nil
            {
                print("fail download")
            }
            else
            {
                print("success download")
                let image = UIImage(data: data!)
                self.currentImage = image ?? UIImage(named: "cake\(0)")!
                
            }
        })
        return currentImage
    }
    
    func uploadImage(image:UIImage, filename:String)
    {
        
        let dataToSend = image.jpegData(compressionQuality: 1.0)
        let imageRef = storageRef?.child(filename)
        imageRef?.putData(dataToSend! , metadata: nil, completion:
            {
                metadata, error in
                //this runs After Firebase is done saving, or whatever it does
                if error != nil
                {
                    print("fail to upload\(error.debugDescription)")
                }
                else
                {
                    print("success opload")
                    variablesRepo.increaseSize(name: "size")
                }
        })
    }
    
    
}
