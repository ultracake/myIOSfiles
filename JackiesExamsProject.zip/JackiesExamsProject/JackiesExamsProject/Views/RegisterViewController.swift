//
//  RegisterViewController.swift
//  JackiesExamsProject
//
//  Created by admin on 23/05/2019.
//  Copyright © 2019 admin. All rights reserved.
//

import UIKit
import FirebaseAuth

class RegisterViewController: UIViewController
{

    @IBOutlet weak var labelWrong: UILabel!
    @IBOutlet weak var usernameInput: UITextField!
    @IBOutlet weak var passwordInput: UITextField!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func registerAccount(_ sender: Any)
    {
        if let usr = usernameInput.text, let pwd = passwordInput.text
        {
            Auth.auth().createUser(withEmail: usr, password: pwd)
            {
                (result, error) in
                if error == nil
                {
                    print("register success")
                    self.performSegue(withIdentifier: "segueRegister", sender: self)
                    
                }else
                {
                    print("some error\(error.debugDescription)")
                    self.labelWrong.text = "Unacceptable username \n or password"
                }
            }
        }
    }
    
   

}
