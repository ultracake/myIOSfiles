//
//  CreateLinksAndNotesViewController.swift
//  JackiesExamsProject
//
//  Created by admin on 24/05/2019.
//  Copyright © 2019 admin. All rights reserved.
//

import UIKit
import FirebaseAuth

class CreateLinksAndNotesViewController: UIViewController
{
    @IBOutlet weak var textfieldLink: UITextField!
    
    @IBOutlet weak var textviewNote: UITextView!
    override func viewDidLoad()
    {
        super.viewDidLoad()

    }
    
    @IBAction func logout(_ sender: Any)
    {
        do
        {
            try Auth.auth().signOut()
            print("logout succssfully")
            self.performSegue(withIdentifier: "segueLogout", sender: self)
        }
        catch
        {
            print("some error \(error.localizedDescription)")
        }
    }
    
  
    @IBAction func createLinkAndNote(_ sender: Any)
    {
        myLocalVar.currentWebLink = "www.dr.dk"
        if let noteText = textviewNote.text , let newlink = textfieldLink.text
        {
           notesRepo.createNote(noteText: noteText, newlink: newlink)
            
        }
       
    }
    
}
