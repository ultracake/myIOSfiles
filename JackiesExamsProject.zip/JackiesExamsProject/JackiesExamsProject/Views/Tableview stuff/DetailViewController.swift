//
//  DetailViewController.swift
//  JackiesExamsProject
//
//  Created by admin on 25/05/2019.
//  Copyright © 2019 admin. All rights reserved.
//

import UIKit



class DetailViewController: UIViewController
{
    var currentIndex = 0 //variable check
    var currentNote:Note?
    var backVal:Float?
    
    @IBOutlet weak var webLinkTextField: UITextField!
    @IBOutlet weak var backImageview: UIImageView!
    @IBOutlet weak var votesIntLabel: UILabel!
    @IBOutlet weak var noteTextview: UITextView!
    @IBOutlet weak var selectbackSlider: UISlider!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        currentNote = notesRepo.notesList[currentIndex]
        
        backImageview.image = UIImage(named: "cake\(currentNote!.background)")
        webLinkTextField.text = currentNote?.weblink
        votesIntLabel.text = String(currentNote!.votes)
        noteTextview.text = currentNote?.note
        selectbackSlider.setValue(Float(currentNote!.background), animated: true)
    }
    
    @IBAction func upVote(_ sender: Any)
    {
        currentNote?.votes += 1
        votesIntLabel.text = String(currentNote!.votes)
    }
    
    @IBAction func downVote(_ sender: Any)
    {
        if currentNote!.votes > 0
        {
            currentNote?.votes -= 1
            votesIntLabel.text = String(currentNote!.votes)
        }
        
    }
    
    @IBAction func changeBackground(_ sender: Any)
    {
        let sliderVal = selectbackSlider.value
        backVal = sliderVal
        backImageview.image = UIImage(named: "cake\(sliderVal)")
    }
    
    @IBAction func saveNoteChanges(_ sender: Any)
    {
        currentNote?.note = noteTextview.text
        currentNote?.background = Int(backVal ?? 0)
        currentNote?.weblink = webLinkTextField.text ?? "google.dk"
        
        notesRepo.saveChanges(currentNote: currentNote!)
        
    }
    
    @IBAction func deleteNoteFromDB(_ sender: Any)
    {
        //use the Repo class for delete
        notesRepo.deleteNote(keyName: currentNote!.weblink)
    }

    @IBAction func GotoLink(_ sender: Any)
    {
        myLocalVar.currentWebLink = "https://" + notesRepo.notesList[currentIndex].weblink
    }
}
