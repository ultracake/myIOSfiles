//
//  ShowWebViewController.swift
//  JackiesExamsProject
//
//  Created by admin on 14/05/2019.
//  Copyright © 2019 admin. All rights reserved.
//

import UIKit
import WebKit


class ShowWebViewController: UIViewController, WKNavigationDelegate
{
    var webView:WKWebView?
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        myInit()
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        myInit()
    }
    
    override func loadView()
    {
        webView = WKWebView()
        webView?.navigationDelegate = self
        self.view = webView
    }
    
    func myInit()
    {
        if(myLocalVar.currentWebLink.contains("www."))
        {
            //1. create URL
            let url = URL(string: myLocalVar.currentWebLink)
            
            //2. load
            webView?.load(URLRequest(url: url!))
        }else
        {
            print("the link is not correct")
        }
    }
    

}
