//
//  ViewController.swift
//  JackiesExamsProject
//
//  Created by admin on 14/05/2019.
//  Copyright © 2019 admin. All rights reserved.
//

import UIKit
import FirebaseAuth

let notesRepo = NotesRepo()
let pictureRepo = PictureRepo()
let variablesRepo = VariablesRepo()
let myLocalVar = MyLocalVar()

class ViewController: UIViewController
{
    
    @IBOutlet weak var labelWrong: UILabel!
    @IBOutlet weak var usernameInput: UITextField!
    @IBOutlet weak var passwordInput: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func login(_ sender: Any)
    {
        if let usr = usernameInput.text, let pwd = passwordInput.text
        {
            Auth.auth().signIn(withEmail: usr, password: pwd)
            {
                (result, error) in
                if error == nil
                {
                    //print(Auth.auth().currentUser?.email)
                    print("login success")
                    self.performSegue(withIdentifier: "segueLogin", sender: self)
                }else
                {
                    print("some error\(error.debugDescription)")
                    self.labelWrong.text = "Wrong Username \n or password"
                }
            }
        }
    }
    
}

