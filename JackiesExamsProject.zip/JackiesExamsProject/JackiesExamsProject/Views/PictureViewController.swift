//
//  FotoViewController.swift
//  JackiesExamsProject
//
//  Created by admin on 07/06/2019.
//  Copyright © 2019 admin. All rights reserved.
//
import UIKit

class PictureViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate
{
    
    let imagePicker = UIImagePickerController()
    
    @IBOutlet weak var sliderValText: UITextField!
    @IBOutlet weak var textForSuccess: UITextView!
    @IBOutlet weak var butOpload: UIButton!
    @IBOutlet weak var sliderForDownload: UISlider!
    @IBOutlet weak var imageAlbumView: UIImageView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        imagePicker.delegate = self
        imagePicker.sourceType = .photoLibrary
        
        textForSuccess.isHidden = true
        sliderForDownload.minimumValue = 1
        sliderForDownload.maximumValue = 5
        sliderValText.text = "current: \(variablesRepo.sizeOfStoredImages)"
    }
    
    @IBAction func download(_ sender: Any)
    {
        //has to make the slidervalue an int to get a whole number
        imageAlbumView.image = pictureRepo.downloadImage(name: "image\(Int(sliderForDownload.value))")
        imageAlbumView.contentMode = .scaleAspectFit
    }
    
    @IBAction func selectpic(_ sender: Any)
    {
        //opens imagePicker
        self.present(imagePicker, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any])
    {
        if let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage
        {
            //set the image to imageview
            imageAlbumView.image = image
            imageAlbumView.contentMode = .scaleAspectFit
        }
    
        butOpload.isHidden = false
        textForSuccess.isHidden = false
        textForSuccess.text = "current numbers of images: \(variablesRepo.sizeOfStoredImages) \n Do you want to upload image?"
        picker.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func opload(_ sender: Any)
    {
        //repo uploads image
        pictureRepo.uploadImage(image: imageAlbumView.image ?? myLocalVar.currentImage, filename: "image\(variablesRepo.sizeOfStoredImages+1)")
        
        if(variablesRepo.sizeOfStoredImages > 5)
        {
            sliderForDownload.maximumValue = Float(variablesRepo.sizeOfStoredImages)
        }
        
        textForSuccess.text = "current numbers of images: \(variablesRepo.sizeOfStoredImages+1) \n Your image is uploaded successfully"
        
    }
    
    @IBAction func sliderValChanges(_ sender: Any)
    {
        sliderValText.text = "current: \(sliderForDownload.value)"
    }
}
